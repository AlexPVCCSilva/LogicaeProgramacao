﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Alex
{
    public partial class FrmExercicio03 : Form
    {
        public FrmExercicio03()
        {
            InitializeComponent();
        }

        private void FrmExercicio03_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            float vlrQuilo = float.Parse(txtQuilo.Text);
            float vlrResult;
            //
            vlrResult = vlrQuilo * 34;
            //
            lblRes.Text = ("voce gastou : " + vlrResult);
        }

        private void lblRes_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Alex
{
    public partial class FrmExercicio06 : Form
    {
        public FrmExercicio06()
        {
            InitializeComponent();
        }
    }
}
